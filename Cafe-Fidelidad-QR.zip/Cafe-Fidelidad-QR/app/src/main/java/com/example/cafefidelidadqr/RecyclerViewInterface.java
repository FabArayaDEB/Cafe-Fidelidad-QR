package com.example.cafefidelidadqr;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
